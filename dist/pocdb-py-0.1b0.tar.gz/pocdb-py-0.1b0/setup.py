from setuptools import setup

setup(name='pocdb-py',
      version='0.1b',
      description='pocdb.com Python SDK',
      url='https://github.com/jeffthorne/pocdb-py',
      author='Jeff Thorne',
      author_email='jthorne@u.washington.edu',
      license='MIT',
      packages=['pocdb', 'pocdb.models', 'pocdb.utils'],
      install_requires=['requests >= 2.18.4'],
      zip_safe=False)